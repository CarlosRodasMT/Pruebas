
package com.example.demo.Interface;

import com.example.demo.Modelo.Cloud;
import org.springframework.data.repository.CrudRepository;

public interface CloudInterface extends CrudRepository<Cloud, Integer>{
    
}
