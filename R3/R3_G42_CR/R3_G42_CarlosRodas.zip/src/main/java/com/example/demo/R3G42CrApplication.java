package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class R3G42CrApplication {

	public static void main(String[] args) {
		SpringApplication.run(R3G42CrApplication.class, args);
	}

}
